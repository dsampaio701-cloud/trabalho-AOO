# Sistema de Biblioteca

## Objetivo
Implementação em Python de um sistema de biblioteca, baseado em um diagrama de
classes UML com as classes **Usuario**, **Livro** e **Emprestimo**.

Funcionalidades implementadas:
- Cadastro de usuários e livros (com validação dos dados);
- Realização de empréstimo (só é possível se o livro estiver disponível);
- Registro de devolução, com cálculo dos dias de atraso;
- Consulta de disponibilidade dos livros e listagem de empréstimos ativos.

## Modelagem
| Classe       | Atributos principais                                   | Métodos (UML → Python)                                               |
|--------------|--------------------------------------------------------|----------------------------------------------------------------------|
| `Usuario`    | id_usuario, nome, matricula, email                     | `cadastrar_usuario`, `atualizar_dados`                               |
| `Livro`      | id_livro, titulo, autor, isbn, status_disponibilidade  | `cadastrar_livro`, `consultar_disponibilidade`, `atualizar_status`   |
| `Emprestimo` | id_emprestimo, datas, status                           | `realizar_emprestimo`, `registrar_devolucao`                         |

Associações: um **Usuário** realiza 0..* **Empréstimos**; um **Livro** integra
0..* **Empréstimos**. A classe `Biblioteca` (`servico.py`) coordena essas relações.

## Tecnologias
- Python 3.9+ (apenas biblioteca padrão, sem dependências externas)
- `unittest` para os testes
- Git/GitHub para versionamento

## Estrutura
```
biblioteca-uml/
├── biblioteca/
│   ├── models.py      # Usuario, Livro, Emprestimo e enums
│   └── servico.py     # classe Biblioteca (regras e associações)
├── tests/
│   ├── test_unidade.py
│   └── test_integracao.py
├── main.py            # menu em linha de comando
└── README.md
```

## Como executar
```bash
git clone <URL-DO-SEU-REPOSITORIO>
cd biblioteca-uml
python main.py
```

## Como rodar os testes
```bash
python -m unittest discover -s tests -v
```
- **Unidade** (`test_unidade.py`): testa `Livro`, `Usuario` e `Emprestimo` isoladamente.
- **Integração** (`test_integracao.py`): testa o fluxo cadastro → empréstimo → devolução.
