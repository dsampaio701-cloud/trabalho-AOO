"""Classes do domínio, conforme o diagrama UML (Usuario, Livro, Emprestimo)."""
from __future__ import annotations

from datetime import date, timedelta
from enum import Enum
from typing import Optional


class StatusDisponibilidade(Enum):
    DISPONIVEL = "Disponível"
    EMPRESTADO = "Emprestado"


class StatusEmprestimo(Enum):
    ATIVO = "Ativo"
    DEVOLVIDO = "Devolvido"


class BibliotecaError(Exception):
    """Erro base do sistema."""


class LivroIndisponivelError(BibliotecaError):
    pass


class EmprestimoInvalidoError(BibliotecaError):
    pass


class DadosInvalidosError(BibliotecaError):
    pass


class Usuario:
    def __init__(self, id_usuario: int, nome: str, matricula: str, email: str):
        self.id_usuario = id_usuario
        self.nome = nome
        self.matricula = matricula
        self.email = email

    def cadastrar_usuario(self) -> None:
        """Valida os dados do usuário antes de ele ser registrado."""
        if not self.nome.strip() or not self.matricula.strip():
            raise DadosInvalidosError("Nome e matrícula são obrigatórios.")
        if "@" not in self.email:
            raise DadosInvalidosError("E-mail inválido.")

    def atualizar_dados(self, nome: Optional[str] = None,
                        email: Optional[str] = None) -> None:
        if nome is not None:
            if not nome.strip():
                raise DadosInvalidosError("Nome não pode ser vazio.")
            self.nome = nome
        if email is not None:
            if "@" not in email:
                raise DadosInvalidosError("E-mail inválido.")
            self.email = email

    def __str__(self) -> str:
        return f"[{self.id_usuario}] {self.nome} (matrícula {self.matricula})"


class Livro:
    def __init__(self, id_livro: int, titulo: str, autor: str, isbn: str):
        self.id_livro = id_livro
        self.titulo = titulo
        self.autor = autor
        self.isbn = isbn
        self.status_disponibilidade = StatusDisponibilidade.DISPONIVEL

    def cadastrar_livro(self) -> None:
        """Valida os dados do livro antes de ele ser registrado."""
        if not self.titulo.strip() or not self.autor.strip():
            raise DadosInvalidosError("Título e autor são obrigatórios.")
        if not self.isbn.strip():
            raise DadosInvalidosError("ISBN é obrigatório.")

    def consultar_disponibilidade(self) -> bool:
        return self.status_disponibilidade == StatusDisponibilidade.DISPONIVEL

    def atualizar_status(self, novo_status: StatusDisponibilidade) -> None:
        self.status_disponibilidade = novo_status

    def __str__(self) -> str:
        return (f"[{self.id_livro}] {self.titulo} - {self.autor} "
                f"({self.status_disponibilidade.value})")


class Emprestimo:
    PRAZO_PADRAO_DIAS = 7

    def __init__(self, id_emprestimo: int, usuario: Usuario, livro: Livro,
                 data_emprestimo: Optional[date] = None,
                 prazo_dias: int = PRAZO_PADRAO_DIAS):
        self.id_emprestimo = id_emprestimo
        self.usuario = usuario
        self.livro = livro
        self.data_emprestimo = data_emprestimo or date.today()
        self.data_devolucao_prevista = self.data_emprestimo + timedelta(days=prazo_dias)
        self.data_devolucao_real: Optional[date] = None
        self.status: Optional[StatusEmprestimo] = None

    def realizar_emprestimo(self) -> None:
        """Efetiva o empréstimo: o livro precisa estar disponível."""
        if not self.livro.consultar_disponibilidade():
            raise LivroIndisponivelError(
                f"O livro '{self.livro.titulo}' não está disponível.")
        self.livro.atualizar_status(StatusDisponibilidade.EMPRESTADO)
        self.status = StatusEmprestimo.ATIVO

    def registrar_devolucao(self, data: Optional[date] = None) -> int:
        """Registra a devolução e retorna os dias de atraso (0 se no prazo)."""
        if self.status != StatusEmprestimo.ATIVO:
            raise EmprestimoInvalidoError("Este empréstimo não está ativo.")
        self.data_devolucao_real = data or date.today()
        self.livro.atualizar_status(StatusDisponibilidade.DISPONIVEL)
        self.status = StatusEmprestimo.DEVOLVIDO
        return max(0, (self.data_devolucao_real - self.data_devolucao_prevista).days)

    def __str__(self) -> str:
        return (f"[{self.id_emprestimo}] {self.livro.titulo} -> {self.usuario.nome} "
                f"| devolução prevista: {self.data_devolucao_prevista:%d/%m/%Y} "
                f"| {self.status.value if self.status else 'Não efetivado'}")
