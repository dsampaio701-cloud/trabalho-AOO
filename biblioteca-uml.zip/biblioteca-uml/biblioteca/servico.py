"""Serviço que coordena as classes do domínio (associações do diagrama)."""
from __future__ import annotations

from datetime import date
from typing import Dict, List, Optional

from .models import (BibliotecaError, Emprestimo, Livro, StatusEmprestimo,
                     Usuario)


class Biblioteca:
    def __init__(self) -> None:
        self.usuarios: Dict[int, Usuario] = {}
        self.livros: Dict[int, Livro] = {}
        self.emprestimos: Dict[int, Emprestimo] = {}
        self._prox_usuario = 1
        self._prox_livro = 1
        self._prox_emprestimo = 1

    def cadastrar_usuario(self, nome: str, matricula: str, email: str) -> Usuario:
        usuario = Usuario(self._prox_usuario, nome, matricula, email)
        usuario.cadastrar_usuario()
        self.usuarios[usuario.id_usuario] = usuario
        self._prox_usuario += 1
        return usuario

    def cadastrar_livro(self, titulo: str, autor: str, isbn: str) -> Livro:
        livro = Livro(self._prox_livro, titulo, autor, isbn)
        livro.cadastrar_livro()
        self.livros[livro.id_livro] = livro
        self._prox_livro += 1
        return livro

    def realizar_emprestimo(self, id_usuario: int, id_livro: int,
                            data: Optional[date] = None) -> Emprestimo:
        usuario = self._buscar(self.usuarios, id_usuario, "Usuário")
        livro = self._buscar(self.livros, id_livro, "Livro")
        emprestimo = Emprestimo(self._prox_emprestimo, usuario, livro, data)
        emprestimo.realizar_emprestimo()  # lança erro se indisponível
        self.emprestimos[emprestimo.id_emprestimo] = emprestimo
        self._prox_emprestimo += 1
        return emprestimo

    def registrar_devolucao(self, id_emprestimo: int,
                            data: Optional[date] = None) -> int:
        emprestimo = self._buscar(self.emprestimos, id_emprestimo, "Empréstimo")
        return emprestimo.registrar_devolucao(data)

    def emprestimos_do_usuario(self, id_usuario: int) -> List[Emprestimo]:
        return [e for e in self.emprestimos.values()
                if e.usuario.id_usuario == id_usuario]

    def emprestimos_ativos(self) -> List[Emprestimo]:
        return [e for e in self.emprestimos.values()
                if e.status == StatusEmprestimo.ATIVO]

    @staticmethod
    def _buscar(colecao: dict, chave: int, nome: str):
        if chave not in colecao:
            raise BibliotecaError(f"{nome} {chave} não encontrado(a).")
        return colecao[chave]
