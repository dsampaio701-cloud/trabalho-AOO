"""Interface de linha de comando do sistema de biblioteca."""
from biblioteca.models import BibliotecaError
from biblioteca.servico import Biblioteca

MENU = """
===== BIBLIOTECA =====
1 - Cadastrar usuário
2 - Cadastrar livro
3 - Realizar empréstimo
4 - Registrar devolução
5 - Listar livros
6 - Listar empréstimos ativos
0 - Sair
"""


def main() -> None:
    bib = Biblioteca()
    while True:
        print(MENU)
        opcao = input("Escolha: ").strip()
        try:
            if opcao == "1":
                u = bib.cadastrar_usuario(input("Nome: "), input("Matrícula: "),
                                          input("E-mail: "))
                print("Cadastrado:", u)
            elif opcao == "2":
                l = bib.cadastrar_livro(input("Título: "), input("Autor: "),
                                        input("ISBN: "))
                print("Cadastrado:", l)
            elif opcao == "3":
                e = bib.realizar_emprestimo(int(input("ID do usuário: ")),
                                            int(input("ID do livro: ")))
                print("Empréstimo realizado:", e)
            elif opcao == "4":
                atraso = bib.registrar_devolucao(int(input("ID do empréstimo: ")))
                print("Devolução registrada.",
                      f"Atraso de {atraso} dia(s)." if atraso else "No prazo.")
            elif opcao == "5":
                for livro in bib.livros.values():
                    print(livro)
            elif opcao == "6":
                for emp in bib.emprestimos_ativos():
                    print(emp)
            elif opcao == "0":
                break
            else:
                print("Opção inválida.")
        except ValueError:
            print("Erro: digite um número válido.")
        except BibliotecaError as erro:
            print("Erro:", erro)


if __name__ == "__main__":
    main()
