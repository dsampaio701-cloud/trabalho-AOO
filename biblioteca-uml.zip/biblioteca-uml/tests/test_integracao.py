"""Teste de integração: fluxo completo cadastro -> empréstimo -> devolução."""
import unittest
from datetime import date

from biblioteca.models import (BibliotecaError, LivroIndisponivelError,
                               StatusEmprestimo)
from biblioteca.servico import Biblioteca


class TestFluxoCompleto(unittest.TestCase):
    def test_fluxo_emprestimo_e_devolucao(self):
        bib = Biblioteca()
        ana = bib.cadastrar_usuario("Ana", "2024001", "ana@email.com")
        bia = bib.cadastrar_usuario("Bia", "2024002", "bia@email.com")
        livro = bib.cadastrar_livro("Dom Casmurro", "Machado de Assis", "123")

        emp = bib.realizar_emprestimo(ana.id_usuario, livro.id_livro, date(2026, 11, 3))
        self.assertFalse(livro.consultar_disponibilidade())
        self.assertEqual(len(bib.emprestimos_ativos()), 1)

        # outro usuário não consegue pegar o mesmo livro
        with self.assertRaises(LivroIndisponivelError):
            bib.realizar_emprestimo(bia.id_usuario, livro.id_livro)

        atraso = bib.registrar_devolucao(emp.id_emprestimo, date(2026, 11, 8))
        self.assertEqual(atraso, 0)
        self.assertEqual(emp.status, StatusEmprestimo.DEVOLVIDO)
        self.assertTrue(livro.consultar_disponibilidade())
        self.assertEqual(len(bib.emprestimos_ativos()), 0)

        # agora a Bia consegue emprestar
        bib.realizar_emprestimo(bia.id_usuario, livro.id_livro)
        self.assertEqual(len(bib.emprestimos_do_usuario(bia.id_usuario)), 1)

    def test_usuario_inexistente(self):
        bib = Biblioteca()
        livro = bib.cadastrar_livro("Livro", "Autor", "1")
        with self.assertRaises(BibliotecaError):
            bib.realizar_emprestimo(99, livro.id_livro)


if __name__ == "__main__":
    unittest.main()
