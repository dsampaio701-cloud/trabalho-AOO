"""Testes de unidade: classes testadas isoladamente."""
import unittest
from datetime import date

from biblioteca.models import (DadosInvalidosError, Emprestimo,
                               EmprestimoInvalidoError, Livro,
                               LivroIndisponivelError, StatusDisponibilidade,
                               StatusEmprestimo, Usuario)


class TestLivro(unittest.TestCase):
    def test_livro_novo_esta_disponivel(self):
        livro = Livro(1, "Dom Casmurro", "Machado de Assis", "123")
        self.assertTrue(livro.consultar_disponibilidade())

    def test_atualizar_status(self):
        livro = Livro(1, "Dom Casmurro", "Machado de Assis", "123")
        livro.atualizar_status(StatusDisponibilidade.EMPRESTADO)
        self.assertFalse(livro.consultar_disponibilidade())

    def test_cadastro_sem_titulo_falha(self):
        with self.assertRaises(DadosInvalidosError):
            Livro(1, " ", "Autor", "123").cadastrar_livro()


class TestUsuario(unittest.TestCase):
    def test_email_invalido(self):
        with self.assertRaises(DadosInvalidosError):
            Usuario(1, "Ana", "2024001", "ana.email.com").cadastrar_usuario()

    def test_atualizar_dados(self):
        u = Usuario(1, "Ana", "2024001", "ana@email.com")
        u.atualizar_dados(nome="Ana Souza")
        self.assertEqual(u.nome, "Ana Souza")


class TestEmprestimo(unittest.TestCase):
    def setUp(self):
        self.usuario = Usuario(1, "Ana", "2024001", "ana@email.com")
        self.livro = Livro(1, "Dom Casmurro", "Machado de Assis", "123")

    def test_realizar_emprestimo_marca_livro_emprestado(self):
        emp = Emprestimo(1, self.usuario, self.livro, date(2026, 11, 3))
        emp.realizar_emprestimo()
        self.assertEqual(emp.status, StatusEmprestimo.ATIVO)
        self.assertFalse(self.livro.consultar_disponibilidade())
        self.assertEqual(emp.data_devolucao_prevista, date(2026, 11, 10))

    def test_emprestar_livro_indisponivel_falha(self):
        self.livro.atualizar_status(StatusDisponibilidade.EMPRESTADO)
        emp = Emprestimo(1, self.usuario, self.livro)
        with self.assertRaises(LivroIndisponivelError):
            emp.realizar_emprestimo()

    def test_devolucao_com_atraso(self):
        emp = Emprestimo(1, self.usuario, self.livro, date(2026, 11, 3))
        emp.realizar_emprestimo()
        atraso = emp.registrar_devolucao(date(2026, 11, 13))
        self.assertEqual(atraso, 3)
        self.assertTrue(self.livro.consultar_disponibilidade())

    def test_devolver_emprestimo_nao_ativo_falha(self):
        emp = Emprestimo(1, self.usuario, self.livro)
        with self.assertRaises(EmprestimoInvalidoError):
            emp.registrar_devolucao()


if __name__ == "__main__":
    unittest.main()
